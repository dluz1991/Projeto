package CodeGenerator;

public enum Tipo {
    INT,    // 0
    REAL,   // 1
    STRING, // 2
    BOOL,   // 3
    ERRO    // 4
}
